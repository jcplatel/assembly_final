function [aligned_red, aligned_green, aligned_blue, calcium_norm, aligned_red890, info] = image_alignment_multimodal(images_norm)
    % Ajout du 11 nov. (ne change RIEN aux 5 premières sorties) : 6e sortie
    % facultative 'info', pour repérer un recalage raté.
    %   info.decalage_1040_px : translation [x y] du bloc 1040 vers le calcium
    %   info.decalage_890_px  : translation [x y] du bloc 890 vers le rouge 1040
    %   info.corr_calcium_avant / _apres : corrélation entre l'image calcium
    %       et le rouge 1040, avant et après recalage (doit monter)
    %   info.corr_rouges_avant / _apres : corrélation entre rouge 890 et
    %       rouge 1040 recalé, avant et après (même fluorophore : doit être
    %       haute après ; c'est le meilleur indicateur)
    % =========================================================================
    % 1. PRÉPARATION DE L'OPTIMISEUR MULTI-MODAL
    % =========================================================================
    [optimizer, metric] = imregconfig('multimodal');
    % On réduit le pas initial pour éviter les divergences
    optimizer.InitialRadius = optimizer.InitialRadius / 5;
    
    % Vue de référence absolue (le calcium fixe)
    ref_view_calcium = imref2d(size(images_norm.calcium));

    % =========================================================================
    % 2. ALIGNEMENT DU BLOC 1040 (Rouge et Vert) SUR LE CALCIUM
    % =========================================================================
    % On calcule la transformation en utilisant le red1040 (souvent plus propre) 
    % par rapport au calcium (fixe).
    tform_1040_to_calcium = imregtform(images_norm.red1040, images_norm.calcium, ...
                                       'translation', optimizer, metric);
    
    % On applique cette transformation au Rouge 1040
    aligned_red = imwarp(images_norm.red1040, tform_1040_to_calcium, ...
                         'OutputView', ref_view_calcium);
                     
    % On applique EXACTEMENT la même transformation au Vert 
    % (car l'image verte est trop bruitée pour guider son propre alignement)
    aligned_green = imwarp(images_norm.green, tform_1040_to_calcium, ...
                           'OutputView', ref_view_calcium);

    % =========================================================================
    % 3. ALIGNEMENT DU BLOC 890 (Rouge 890 et Bleu) SUR LE ROUGE 1040 ALIGNÉ
    % =========================================================================
    % Ici, le red1040_aligné devient la nouvelle image de référence (fixe).
    % Le red890 est l'image qui bouge pour rattraper le red1040.
    tform_890_to_red1040 = imregtform(images_norm.red890, aligned_red, ...
                                      'translation', optimizer, metric);
                                  
    % On applique la transformation au Rouge 890
    aligned_red890 = imwarp(images_norm.red890, tform_890_to_red1040, ...
                            'OutputView', ref_view_calcium);
                        
    % On applique la même transformation au Bleu (acquis en même temps que le R890)
    aligned_blue = imwarp(images_norm.blue, tform_890_to_red1040, ...
                          'OutputView', ref_view_calcium);

    % =========================================================================
    % 4. FINALISATION ET NETTOYAGE
    % =========================================================================
    calcium_norm = images_norm.calcium; % Le calcium n'a pas bougé
    
    % imwarp peut parfois créer de très légères valeurs négatives lors des 
    % interpolations aux bords. On ramène tout ce qui est sous 0 à 0.
    aligned_red(aligned_red < 0) = 0;
    aligned_green(aligned_green < 0) = 0;
    aligned_blue(aligned_blue < 0) = 0;
    aligned_red890(aligned_red890 < 0) = 0;

    if nargout >= 6
        cc = @(a, b) subsref(corrcoef(double(a(:)), double(b(:))), struct('type', '()', 'subs', {{1, 2}}));
        info = struct();
        info.decalage_1040_px   = translation_de(tform_1040_to_calcium);
        info.decalage_890_px    = translation_de(tform_890_to_red1040);
        info.corr_calcium_avant = cc(images_norm.calcium, images_norm.red1040);
        info.corr_calcium_apres = cc(images_norm.calcium, aligned_red);
        info.corr_rouges_avant  = cc(images_norm.red890, aligned_red);
        info.corr_rouges_apres  = cc(aligned_red890, aligned_red);
    end

end

function t = translation_de(tform)
    % translation [x y] quelle que soit la version de MATLAB (affine2d ou transltform2d)
    if isprop(tform, 'Translation')
        t = tform.Translation;
    else
        t = tform.T(3, 1:2);
    end
end
