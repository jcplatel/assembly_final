function T = figure_screening_comptes(dossier, reference)
%FIGURE_SCREENING_COMPTES  Screening : ce que chaque réglage du prétraitement
%   produit, en nombres (14 nov., demandé par l'utilisateur).
%
%   Pour chaque réglage du prétraitement, sur toutes les sessions du screening :
%     A. nombre de transients (pics) détectés
%     B. nombre de SCE détectés (trait : SCE attendus par hasard)
%     C. nombre d'assemblées (clair : toutes ; foncé : testables)
%     D. nombre d'assemblées biaisées (trait : attendu par hasard) et %
%   C et D dépendent des réglages des assemblées : ils sont donnés pour UNE
%   combinaison de référence (barres), la même pour tous les prétraitements,
%   et en moyenne sur toutes les combinaisons d'assemblées (points noirs).
%
%   figure_screening_comptes                 dossier du screening de config_brainbow,
%                                            référence = réglages d'assemblées de la
%                                            meilleure combinaison classée
%   figure_screening_comptes(dossier)        dossier ...\screening\resultats
%   figure_screening_comptes(dossier, ref)   ref : la ligne du résumé, copiée telle quelle, ex.
%       'clusters rang 95 | FDR_Q=0.05 | v2 | consensus 0.5 K4-14 | >= 15 cellules, >= 5 SCE'
%       (un « prétraitement ... | » au début est ignoré)
%
%   Ne recalcule rien : lit screening.mat et, pour A et B, pretraitement.mat
%   de chaque étape 1 du screening (les dossiers doivent encore exister).
%   Écrit figure_screening_comptes.png et screening_comptes.csv dans le dossier.

if nargin < 1 || isempty(dossier)
    config = config_brainbow();
    dossier = fullfile(fileparts(regexprep(char(config.PathSave), '[\\/]+$', '')), 'screening', 'resultats');
end
if nargin < 2, reference = ''; end
dossier = char(dossier);
Sf = load(fullfile(dossier, 'screening.mat'), 'S');
S = Sf.S;
C = S.C; G = S.G;

%% Combinaison de référence (réglages des assemblées)
if isempty(reference)
    cle = C.exces;
    cle(~(C.eligible > 0) | isnan(cle)) = -Inf;
    [~, k] = max(cle);
    ref = [C.r(k), C.m(k), C.v(k), C.c(k), C.imc(k), C.ims(k)];
else
    ref = lire_reference(char(reference), G);
end
texte_ref = sprintf('clusters %s %g | %s | %s | %s | >= %g cells, >= %g SCE', G.clusters{ref(1), 1}, ...
    G.clusters{ref(1), 2}, G.membres(ref(2)).nom, G.versions{ref(3)}, G.choix_K(ref(4)).nom, ...
    G.min_cellules(ref(5)), G.min_SCE(ref(6)));
de_ref = C.r == ref(1) & C.m == ref(2) & C.v == ref(3) & C.c == ref(4) & C.imc == ref(5) & C.ims == ref(6);

%% Comptes par prétraitement
iP = find(ismember({G.pre.nom}, S.pre_complets));
nP = numel(iP);
nS = numel(S.sessions);
T = struct();
T.reglage = cell(nP, 1);
champs = {'n_transients', 'n_SCE', 'n_SCE_hasard', 'n_sessions_lues', 'n_asm', 'n_testables', 'n_biaisees', ...
    'attendu', 'exces_points', 'moy_asm', 'moy_testables', 'moy_biaisees', 'moy_attendu'};
for i = 1:numel(champs), T.(champs{i}) = nan(nP, 1); end
for i = 1:nP
    p = iP(i);
    if strcmp(G.pre(p).facteur, 'base')
        T.reglage{i} = 'base';
    else
        T.reglage{i} = sprintf('%s: %s', G.pre(p).facteur, G.pre(p).niveau);
    end
    % A, B : transients et SCE, lus dans l'étape 1 de chaque session
    nt = 0; ns = 0; nh = 0; lues = 0;
    for s = 1:nS
        f = fullfile(G.pre(p).dossier, S.sessions{s}, 'pretraitement.mat');
        if ~isfile(f), continue; end
        try
            P = load(f, 'n_transients_total', 'diagnostic');
            nt = nt + double(P.n_transients_total);
            ns = ns + double(P.diagnostic.NRace);
            if isfield(P.diagnostic, 'n_SCE_hasard') && ~isempty(P.diagnostic.n_SCE_hasard)
                nh = nh + double(P.diagnostic.n_SCE_hasard);
            else
                nh = NaN;
            end
            lues = lues + 1;
        catch
        end
    end
    T.n_sessions_lues(i) = lues;
    if lues == nS
        T.n_transients(i) = nt; T.n_SCE(i) = ns; T.n_SCE_hasard(i) = nh;
    end
    % C, D : combinaison de référence, et moyenne de toutes les combinaisons
    du_p = C.ip == p;
    k = find(du_p & de_ref, 1);
    if ~isempty(k)
        T.n_asm(i) = C.n_asm(k); T.n_testables(i) = C.n_test(k); T.n_biaisees(i) = C.n_sig(k);
        T.attendu(i) = C.attendu(k); T.exces_points(i) = 100 * C.exces(k);
    end
    if any(du_p)
        T.moy_asm(i) = mean(C.n_asm(du_p)); T.moy_testables(i) = mean(C.n_test(du_p));
        T.moy_biaisees(i) = mean(C.n_sig(du_p)); T.moy_attendu(i) = mean(C.attendu(du_p));
    end
end
T.reference = texte_ref;
T.sessions = S.sessions;

%% Tableau (écran et csv)
fprintf('\n=== SCREENING : COMPTES PAR RÉGLAGE DU PRÉTRAITEMENT (%d sessions) ===\n', nS);
fprintf('Assemblées : %s\n', texte_ref);
fprintf('%-34s %11s %7s %9s %6s %10s %9s %8s\n', 'réglage', 'transients', 'SCE', '(hasard)', 'asm', ...
    'testables', 'biaisées', 'attendu');
for i = 1:nP
    fprintf('%-34s %11.0f %7.0f %9.0f %6.0f %10.0f %9.0f %8.1f\n', T.reglage{i}, T.n_transients(i), T.n_SCE(i), ...
        T.n_SCE_hasard(i), T.n_asm(i), T.n_testables(i), T.n_biaisees(i), T.attendu(i));
end
if any(T.n_sessions_lues < nS)
    fprintf(2, ['Transients et SCE absents pour %d réglage(s) : pretraitement.mat introuvable ou illisible pour ' ...
        'certaines sessions (dossiers d''étape 1 du screening déplacés ou supprimés ?).\n'], sum(T.n_sessions_lues < nS));
end
try
    fid = fopen(fullfile(dossier, 'screening_comptes.csv'), 'w', 'n', 'UTF-8');
    fprintf(fid, 'reglage,%s\n', strjoin(champs, ','));
    for i = 1:nP
        v = cellfun(@(c) sprintf('%.6g', T.(c)(i)), champs, 'UniformOutput', false);
        fprintf(fid, '"%s",%s\n', T.reglage{i}, strjoin(v, ','));
    end
    fclose(fid);
catch err
    fprintf(2, 'screening_comptes.csv non écrit (%s)\n', err.message);
end

%% Figure
try
    gris = [0.55 0.55 0.55]; bleu = [0.35 0.50 0.75]; bleu_clair = [0.75 0.82 0.92]; rouge = [0.80 0.15 0.15];
    y = (1:nP)';
    fig = figure('Color', 'w', 'Position', [40 60 1700 max(420, 26 * nP + 170)]);
    tl = tiledlayout(fig, 1, 4, 'TileSpacing', 'compact', 'Padding', 'compact');
    title(tl, {sprintf('Settings screening, counts per preprocessing setting: %s (%d sessions)', ...
        strjoin(S.animaux, ', '), nS), ['Assemblies (C, D): ' texte_ref]}, 'FontSize', 10, 'Interpreter', 'none');

    % A. transients
    ax = nexttile(tl); hold(ax, 'on');
    barh(ax, y, T.n_transients, 0.7, 'FaceColor', gris, 'EdgeColor', 'none');
    mise_en_forme(ax, T.reglage, true, 'A. Transients (peaks)', {'transients, all sessions', ' '});

    % B. SCE
    ax = nexttile(tl); hold(ax, 'on');
    barh(ax, y, T.n_SCE, 0.7, 'FaceColor', gris, 'EdgeColor', 'none');
    plot(ax, [T.n_SCE_hasard, T.n_SCE_hasard]', [y - 0.35, y + 0.35]', '-', 'Color', 'k', 'LineWidth', 1.5);
    mise_en_forme(ax, T.reglage, false, 'B. SCE detected', {'SCE, all sessions', '(black line: expected by chance)'});

    % C. assemblées
    ax = nexttile(tl); hold(ax, 'on');
    barh(ax, y, T.n_asm, 0.7, 'FaceColor', bleu_clair, 'EdgeColor', 'none');
    barh(ax, y, T.n_testables, 0.7, 'FaceColor', bleu, 'EdgeColor', 'none');
    plot(ax, T.moy_testables, y, 'o', 'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'k', 'MarkerSize', 4);
    mise_en_forme(ax, T.reglage, false, 'C. Assemblies (light: all, dark: testable)', ...
        {'assemblies, all sessions', '(dot: testable, mean of all assembly settings)'});

    % D. assemblées biaisées
    ax = nexttile(tl); hold(ax, 'on');
    barh(ax, y, T.n_biaisees, 0.7, 'FaceColor', rouge, 'EdgeColor', 'none');
    plot(ax, [T.attendu, T.attendu]', [y - 0.35, y + 0.35]', '-', 'Color', 'k', 'LineWidth', 1.5);
    plot(ax, T.moy_biaisees, y, 'o', 'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'k', 'MarkerSize', 4);
    xmax = max([T.n_biaisees; T.moy_biaisees; 1], [], 'omitnan');
    for i = 1:nP
        if isnan(T.n_testables(i)), continue; end
        text(ax, max(T.n_biaisees(i), 0) + 0.03 * xmax, y(i), sprintf('%d/%d (%.0f%%)', T.n_biaisees(i), ...
            T.n_testables(i), 100 * T.n_biaisees(i) / max(T.n_testables(i), 1)), 'FontSize', 7, ...
            'VerticalAlignment', 'middle');
    end
    xlim(ax, [0, 1.45 * xmax]);
    mise_en_forme(ax, T.reglage, false, 'D. Biased assemblies (p_minp < 0.05)', ...
        {'biased assemblies, all sessions', '(black line: expected by chance; dot: mean of all assembly settings)'});

    exportgraphics(fig, fullfile(dossier, 'figure_screening_comptes.png'), 'Resolution', 150);
    fprintf('Figure : %s\n', fullfile(dossier, 'figure_screening_comptes.png'));
catch err
    warning('figure_screening_comptes : %s', err.message);
end
end


function mise_en_forme(ax, noms, avec_noms, titre, etiquette)
n = numel(noms);
set(ax, 'YDir', 'reverse', 'YLim', [0.3, n + 0.7], 'YTick', 1:n, 'TickDir', 'out', 'Box', 'off', ...
    'FontSize', 8, 'TickLabelInterpreter', 'none');
if avec_noms
    set(ax, 'YTickLabel', noms);
else
    set(ax, 'YTickLabel', {});
end
title(ax, titre, 'FontSize', 10, 'Interpreter', 'none');
xlabel(ax, etiquette);
end


function ref = lire_reference(texte, G)
% Ligne du résumé -> indices [clusters, membres, version, choix_K, min_cellules, min_SCE]
parts = strtrim(strsplit(texte, '|'));
parts = parts(~cellfun(@isempty, parts));
if ~isempty(parts) && ~isempty(regexp(parts{1}, '^pr.traitement', 'once'))
    parts(1) = [];
end
if numel(parts) ~= 5
    error(['Référence non comprise : "%s". Attendu, comme dans le résumé : ' ...
        '''clusters rang 95 | FDR_Q=0.05 | v2 | consensus 0.5 K4-14 | >= 15 cellules, >= 5 SCE'''], texte);
end
noms_cl = cellfun(@(a, b) sprintf('clusters %s %g', a, b), G.clusters(:, 1), G.clusters(:, 2), 'UniformOutput', false);
r = find(strcmp(noms_cl, parts{1}), 1);
m = find(strcmp({G.membres.nom}, parts{2}), 1);
v = find(strcmp(G.versions, parts{3}), 1);
c = find(strcmp({G.choix_K.nom}, parts{4}), 1);
nb = regexp(parts{5}, '>=\s*([\d.]+)\s*cellules\s*,\s*>=\s*([\d.]+)\s*SCE', 'tokens', 'once');
imc = []; ims = [];
if ~isempty(nb)
    imc = find(G.min_cellules == str2double(nb{1}), 1);
    ims = find(G.min_SCE == str2double(nb{2}), 1);
end
noms = {'clusters', 'membres', 'version', 'choix du K', 'minimum de cellules', 'minimum de SCE'};
trouve = {r, m, v, c, imc, ims};
manque = cellfun(@isempty, trouve);
if any(manque)
    error('Référence : %s introuvable(s) dans la grille du screening (texte : "%s").', ...
        strjoin(noms(manque), ', '), texte);
end
ref = [r, m, v, c, imc, ims];
end
