# Journal des versions du pipeline brainbow

Chaque envoi du code a un numéro (`version_pipeline`), dans le nom du zip
(`pipeline_brainbow_<version>.zip`) et dans `parametres_analyse.txt` de chaque
analyse lancée avec. Pour revenir en arrière : reprendre le zip de la version
voulue. Les versions avant le 11 nov. au soir n'avaient pas de numéro (zip
toujours au même nom) ; elles sont résumées ici de mémoire du projet.

## 2026.11.11c (11 nov., soir)
- Version 2 des assemblées (`config.version_assemblees = 'v2'`) : une cellule
  reste membre de tous les clusters où elle est significative
  (`RACEORTHO_V2`, `creer_assemblees_v2`, `fichier_assemblees`, `est_v2`).
  Analyse à part, nom en `_v2`. Version 1 inchangée.
- Consensus : une paire comptée une fois par K (sans effet en version 1).
- Numéro de version (`version_pipeline`) et ce journal.

## 2026.11.11b (11 nov.)
- `comparer_analyses` : tableau de toutes les analyses déjà faites (relit
  aussi les anciennes sans bilan).
- `verifier_couleurs` : contrôle des fichiers colorcell.
- `visionneuse_composite` + bouton « Composite viewer... » de l'interface
  (canaux rouge, vert, bleu, calcium ; masques numérotés parmi iscell).
- Étape 4 : FDR de sensibilité sur les assemblées à `p_min_atteignable` <
  `config.agreg.fdr_filtre_pmin`.
- `main_paires_assemblees` : paires de même couleur dans les assemblées,
  pondérées par la rareté.

## 2026.11.09 – 10
- Interface : image du milieu = couleurs de tout le champ ; camemberts
  (champ, assemblée affichée) ; raster plus étroit.
- Relecture complète du code ; fonction interne des camemberts renommée.

## 2026.11.08
- Seuil des SCE : `sce_minimum` séparé du seuil fixe.
- Co-participation aux SCE ('sce') en 3b et 3d ; `main_clonal_tous_K` ;
  `diagnostic_SCE_assemblees` + figure ; 3e image de l'interface (une
  assemblée à la fois, p et p_minp à chaque K).

## Avant
Voir `LISEZMOI.md` (sections datées) et le document du projet
`etat_pipeline_brainbow.md`.
