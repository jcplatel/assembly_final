function config = dossiers_analyse(config)
%DOSSIERS_ANALYSE  Où sont lus et écrits les résultats.
%
%   Un dossier par réglage de l'étape 1 (config.PathSave). Les autres
%   analyses faites sur CETTE étape 1 (autre règle de choix du K, autres
%   tests...) sont rangées DEDANS, dans analyses\<nom> :
%
%   <PathSave>\                        ex. ...\resultats
%       <session>\pretraitement.mat    étape 1 (commune à toutes les analyses)
%       <session>\k<K>\assemblees.mat  étape 1
%       <session>\choix_K.mat          étape 2  \
%       <session>\clonal\, paires\     étapes 3, 3b > analyse principale
%       agregation\, paires_agregation\  étape 4  /
%       analyses\<nom>\                autre analyse, même étape 1 :
%           <session>\choix_K.mat, clonal\, paires\
%           agregation\, paires_agregation\
%
%   config.analyse = ''      analyse principale : tout dans PathSave
%   config.analyse = 'nom'   étapes 2, 3, 3b, 4 dans <PathSave>\analyses\nom ;
%                            l'étape 1 reste lue (et écrite) dans PathSave
%   Une analyse ne contient jamais d'étape 1 : c'est toujours celle du
%   dossier qui la contient. Pour la garder en changeant d'ordinateur, on
%   déplace tout le dossier PathSave.
%
%   Après l'appel :
%     config.PathEtape1  dossier de l'étape 1
%     config.PathSave    dossier des étapes 2 à 4 (et du journal)
%     config.PathSource  = PathEtape1 (lu par lire_table_sessions)
%   Un deuxième appel ne change rien.
%   Anciens scripts : config.PathSource donné sans config.analyse -> étape 1
%   lue dans PathSource, étapes 2 à 4 dans PathSave (comme avant).

if isfield(config, 'PathEtape1') && ~isempty(config.PathEtape1)
    return      % déjà fait
end
nom = '';
if isfield(config, 'analyse') && ~isempty(config.analyse)
    nom = strtrim(char(config.analyse));
end
if ~isempty(nom)
    if ~isempty(regexp(nom, '[\\/:*?"<>|]', 'once')) || any(strcmp(nom, {'.', '..'}))
        error('Nom d''analyse invalide : "%s" (sans \\ / : * ? " < > |).', nom);
    end
    config.analyse = nom;
    config.PathEtape1 = config.PathSave;
    config.PathSave = fullfile(config.PathSave, 'analyses', nom);
elseif isfield(config, 'PathSource') && ~isempty(config.PathSource)
    config.analyse = '';
    config.PathEtape1 = config.PathSource;
else
    config.analyse = '';
    config.PathEtape1 = config.PathSave;
end
config.PathSource = config.PathEtape1;
end
