# Journal des versions du pipeline brainbow

Chaque envoi du code a un numéro (`version_pipeline`), dans le nom du zip
(`pipeline_brainbow_<version>.zip`) et dans `parametres_analyse.txt` de chaque
analyse lancée avec. Pour revenir en arrière : reprendre le zip de la version
voulue. Les versions avant le 11 nov. au soir n'avaient pas de numéro (zip
toujours au même nom) ; elles sont résumées ici de mémoire du projet.

## 2026.11.13a (13 nov.)
- `screening_reglages` (nouveau) : essaie beaucoup de réglages sur quelques
  animaux (446178, 444119, 444175 par défaut) et classe les combinaisons par
  excès d'assemblées biaisées. Prétraitement : un réglage changé à la fois,
  étape 1 refaite (long). Assemblées : clusters retenus, règle des membres,
  version 1 / 2, chaque K, 'exces', consensus, critères de l'étape 4, tout
  recalculé sans refaire le k-means. Mesure aussi ce que le tri donne par
  hasard (couleurs mélangées, screening refait : `p_selection`).
  Fichiers : `screening/` (`grille_screening`, `screening_session`,
  `screening_agregation`, `table_minp`, `resume_screening`),
  `figures/figure_screening`.
- `screening_reglages(config, struct('etapes', {{'plan'}}))` : ne calcule
  rien, affiche les sessions, les réglages et le nombre d'étapes 1 à faire.
- `consensus_assemblees` : accepte des assemblées données directement
  (`opts.assemblees_K`), pour le screening. Rien ne change pour le pipeline.
- Aucun changement dans les étapes 1 à 5 ni dans les résultats existants.

## 2026.11.12a (12 nov.)
- Contrôles du champ, regroupement spatial des couleurs (figure
  colour_spatial_clustering, panneaux A-C, et résumé) : une seule mesure dans
  toute la figure, le comptage des panneaux D et E. Paires de même couleur à
  moins de `config.paires.rayon_principal_um` (100 µm), observées / attendues
  après mélange des couleurs ; > 1 = regroupées. Avant : indice de distance
  (< 1 = regroupées), gardé dans le CSV et une ligne du résumé.
  `regroupement_couleurs` a un 5e argument (rayon). Étape 4 à relancer.

## 2026.11.11d (11 nov., 23 h)
- `verifier_couleurs`, contrôle 6 : l'image Brainbow (compositecalcium.tif)
  est-elle posée sur les masques suite2p ? Cherche le décalage de l'image
  qui met le plus de lumière dans les masques (`alignement_composite`) ;
  signale aussi les bords vides (grand décalage au recalage) et un canal
  calcium décalé. Le contrôle 4 (voisines de même couleur) ne voyait pas un
  recalage raté (443669_220615_plane0).
- La visionneuse et le contrôle ouvrent d'abord compositecalcium.tif
  (`trouver_composite`).

## 2026.11.11c (11 nov., soir)
- Version 2 des assemblées (`config.version_assemblees = 'v2'`) : une cellule
  reste membre de tous les clusters où elle est significative
  (`RACEORTHO_V2`, `creer_assemblees_v2`, `fichier_assemblees`, `est_v2`).
  Analyse à part, nom en `_v2`. Version 1 inchangée.
- Consensus : une paire comptée une fois par K (sans effet en version 1).
- Numéro de version (`version_pipeline`) et ce journal.

## 2026.11.11b (11 nov.)
- `comparer_analyses` : tableau de toutes les analyses déjà faites (relit
  aussi les anciennes sans bilan).
- `verifier_couleurs` : contrôle des fichiers colorcell.
- `visionneuse_composite` + bouton « Composite viewer... » de l'interface
  (canaux rouge, vert, bleu, calcium ; masques numérotés parmi iscell).
- Étape 4 : FDR de sensibilité sur les assemblées à `p_min_atteignable` <
  `config.agreg.fdr_filtre_pmin`.
- `main_paires_assemblees` : paires de même couleur dans les assemblées,
  pondérées par la rareté.

## 2026.11.09 – 10
- Interface : image du milieu = couleurs de tout le champ ; camemberts
  (champ, assemblée affichée) ; raster plus étroit.
- Relecture complète du code ; fonction interne des camemberts renommée.

## 2026.11.08
- Seuil des SCE : `sce_minimum` séparé du seuil fixe.
- Co-participation aux SCE ('sce') en 3b et 3d ; `main_clonal_tous_K` ;
  `diagnostic_SCE_assemblees` + figure ; 3e image de l'interface (une
  assemblée à la fois, p et p_minp à chaque K).

## Avant
Voir `LISEZMOI.md` (sections datées) et le document du projet
`etat_pipeline_brainbow.md`.
