function colorcell = couleurs_sans_doublons(colorcell, session)
%COULEURS_SANS_DOUBLONS  Les ROI retirées à l'étape 1 sont traitées comme
%   non colorées (8 = none) : doublons (detecter_doublons : même cellule
%   comptée deux fois ; sinon sa couleur compterait deux fois) et ROI trop
%   petites ou trop grandes (tailles_roi). Sans effet si l'étape 1 a été
%   faite sans config.pre.retirer_doublons / retirer_tailles.
dossier = session.dossier;
if isfield(session, 'dossier_source') && ~isempty(session.dossier_source)
    dossier = session.dossier_source;
end
f = fullfile(dossier, 'pretraitement.mat');
if ~isfile(f) || ~ismember('diagnostic', who('-file', f)), return; end
S = load(f, 'diagnostic');
r = zeros(1, 0);
if isfield(S.diagnostic, 'doublons') && isfield(S.diagnostic.doublons, 'retirees')
    r = [r, S.diagnostic.doublons.retirees(:)'];
end
if isfield(S.diagnostic, 'tailles_roi') && isfield(S.diagnostic.tailles_roi, 'retirees')
    r = [r, S.diagnostic.tailles_roi.retirees(:)'];
end
r = r(r >= 1 & r <= numel(colorcell));
colorcell(r) = 8;
end
